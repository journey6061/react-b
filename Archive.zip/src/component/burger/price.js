import React from 'react';

const price=(props)=>{
    return(
        <div>{props.customprice}</div>
    )
}

export default price;